import argparse
from pubmed_paper_fetcher.fetcher import fetch_and_save_papers

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with pharma affiliations.")
    parser.add_argument("query", type=str, help="PubMed query string")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("-f", "--file", type=str, default=None, help="Output CSV file")
    args = parser.parse_args()

    fetch_and_save_papers(query=args.query, filename=args.file, debug=args.debug)
