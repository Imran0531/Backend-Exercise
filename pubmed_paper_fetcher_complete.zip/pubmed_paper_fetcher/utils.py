def is_pharma_affiliated(text: str) -> bool:
    keywords = ["pharma", "biotech", "inc", "ltd", "gmbh", "corp", "therapeutics"]
    return any(k.lower() in text.lower() for k in keywords)

def is_non_academic(text: str) -> bool:
    academic_domains = [".edu", ".ac.", "university", "institute", "college"]
    return not any(domain.lower() in text.lower() for domain in academic_domains)
