import requests
import xmltodict
import pandas as pd
from pubmed_paper_fetcher.utils import is_pharma_affiliated, is_non_academic

BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

def fetch_and_save_papers(query: str, filename: str | None = None, debug: bool = False):
    # Step 1: Search
    search_url = f"{BASE_URL}esearch.fcgi?db=pubmed&term={query}&retmax=20&retmode=json"
    search_response = requests.get(search_url).json()
    ids = search_response["esearchresult"].get("idlist", [])

    if debug:
        print(f"Found IDs: {ids}")

    # Step 2: Fetch summaries
    ids_str = ",".join(ids)
    fetch_url = f"{BASE_URL}efetch.fcgi?db=pubmed&id={ids_str}&retmode=xml"
    fetch_response = requests.get(fetch_url).text
    articles = xmltodict.parse(fetch_response)["PubmedArticleSet"]["PubmedArticle"]

    if isinstance(articles, dict):
        articles = [articles]

    records = []
    for article in articles:
        medline = article["MedlineCitation"]
        article_data = medline["Article"]
        pub_id = medline.get("PMID", {}).get("#text", "")
        title = article_data.get("ArticleTitle", "")
        pub_date = article_data.get("Journal", {}).get("JournalIssue", {}).get("PubDate", {}).get("Year", "")

        authors = article_data.get("AuthorList", {}).get("Author", [])
        if isinstance(authors, dict):
            authors = [authors]

        non_academic = []
        company_affiliations = []
        corresponding_email = ""

        for author in authors:
            affil_info = author.get("AffiliationInfo", [])
            if isinstance(affil_info, dict):
                affil_info = [affil_info]
            for aff in affil_info:
                text = aff.get("Affiliation", "")
                if is_pharma_affiliated(text):
                    company_affiliations.append(text)
                if is_non_academic(text):
                    non_academic.append(text)
                if "@" in text and not corresponding_email:
                    corresponding_email = text[text.find("@") - 10:text.find("@") + 15].split()[-1]

        if company_affiliations:
            records.append({
                "PubmedID": pub_id,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": "; ".join(set(non_academic)),
                "Company Affiliation(s)": "; ".join(set(company_affiliations)),
                "Corresponding Author Email": corresponding_email
            })

    df = pd.DataFrame(records)
    if filename:
        df.to_csv(filename, index=False)
    else:
        print(df)
