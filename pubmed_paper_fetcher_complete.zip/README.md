# PubMed Paper Fetcher

This tool fetches research papers from PubMed with at least one author affiliated with a pharmaceutical or biotech company.

## Project Structure

- `pubmed_paper_fetcher/`: Main package.
- `tests/`: Unit tests.
- `pyproject.toml`: Project configuration and dependencies.

## Usage

```bash
poetry install
poetry run get-papers-list "<your query>" -f results.csv
```

## Dependencies

- requests
- xmltodict
- pandas

## Author Identification Heuristics

- Non-academic emails (not ending in `.edu`, `.ac.<country>`)
- Keywords like "Pharma", "Biotech", or company names in affiliations
